-- Active: 1741609824793@@127.0.0.1@5432@hrms_new
create table employees(
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    DOB date not NULL,
    DOJ date not NULL,
    phone VARCHAR(10) not NULL check (length(phone)=10),
    designation VARCHAR(100) not null,
    department VARCHAR(100) not null,
    created_at TIMESTAMP DEFAULT current_timestamp
)

create table users (
    id SERIAL PRIMARY KEY,
    employee_id INT REFERENCES employees(id) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) CHECK (role IN ('admin', 'user')) NOT NULL,
    token VARCHAR(255),
    created_at TIMESTAMP DEFAULT current_timestamp
);

create table earning_deduction_master(
    id SERIAL PRIMARY KEY,
    description VARCHAR(255) NOT NULL UNIQUE, --basic pay/hra/bonus/income tax/pf/any other new component
    type SMALLINT NOT NULL, --let's say 0 for earning and 1 for deduction.
    created_at TIMESTAMP DEFAULT current_timestamp,
    status BOOLEAN DEFAULT true --0/1 -> active/inactive
)

CREATE TABLE employee_earnings_deductions(
    id serial PRIMARY KEY,
    employee_id int REFERENCES employees(id) NOT NULL,
    earning_deduction_id int REFERENCES earning_deduction_master(id) NOT NULL,
    amount NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT current_timestamp
);
ALTER TABLE employee_earnings_deductions
ADD CONSTRAINT unique_emp_earning_deduction UNIQUE (employee_id, earning_deduction_id);--> much needed

create table employee_salary(
    id serial PRIMARY KEY,
    employee_id int REFERENCES employees(id) NOT NULL, 
    month int not null check(month>=1 and month<=12),
    year int not null,
    net_salary NUMERIC(10,2),
    created_at TIMESTAMP DEFAULT current_timestamp,
    status BOOLEAN DEFAULT true,
    salary_paid BOOLEAN DEFAULT false,
    constraint uni_monthly_employee_record UNIQUE (employee_id, month, year)
)

create table employee_salary_earning_deduction(
    id serial PRIMARY KEY,
    salary_id int REFERENCES employee_salary(id) not null,
    employee_earning_deduction_id int REFERENCES employee_earnings_deductions(id) not null,
    amount NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT current_timestamp,
    status BOOLEAN DEFAULT true
)

create table leaves (
    id SERIAL PRIMARY KEY,
    employee_id INT REFERENCES employees(id) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    total_leaves INT GENERATED ALWAYS AS ((end_date - start_date + 1)) STORED,
    status VARCHAR(20) not NULL DEFAULT 'Pending' CHECK (status IN ('Approved', 'Rejected', 'Pending')),
    created_at timestamp DEFAULT current_timestamp
);


 INSERT INTO employees (name, DOB, DOJ, phone, designation, department)
VALUES 
('Yash Chary', '1990-05-15', '2015-04-20', '9876543210', 'Engineer', 'IT'),
('Anu Verma', '1988-11-10', '2016-03-15', '9823456789', 'Engineer', 'IT'),
('Priya Gupta', '1992-03-20', '2017-07-10', '9871234567', 'HR Executive', 'HR'),
('Neha Singh', '1995-01-05', '2019-10-05', '9876541234', 'Accountant', 'Finance'),
('Rajesh Kumar', '1985-09-18', '2012-05-12', '9898765432', 'Technician', 'Maintenance');

INSERT INTO users (employee_id, email, password, role)
VALUES 
(1, 'yash.chary@gmail.com', md5('abcd@1234'), 'admin'),
(2, 'anu.verma@gmail.com', md5('anuV3rm@'), 'user'),
(3, 'priya.gupta@gmail.com', md5('priya@123'), 'user'),
(4, 'neha.singh@gmail.com', md5('neha@456'), 'user'),
(5, 'rajesh.kumar@gmail.com', md5('rajesh@987'), 'user');

INSERT INTO earning_deduction_master (description, type)
VALUES 
('Basic Pay', 0),
('HRA', 0),
('Bonus', 0),
('Income Tax', 1),
('Provident Fund', 1),
('Medical Allowance', 0),
('Professional Tax', 1),
('Special Allowance', 0);

INSERT INTO employee_earnings_deductions (employee_id, earning_deduction_id, amount)
VALUES 
(1, 1, 40000), 
(1, 2, 10000), 
(1, 3, 5000),  
(1, 4, 3000),  
(1, 5, 2000),  
(2, 1, 50000), 
(2, 2, 12000), 
(2, 3, 7000),  
(2, 4, 4000),  
(2, 5, 3000);  



INSERT INTO employee_salary (employee_id, month, year, net_salary, salary_paid)
VALUES 
(1, 3, 2025, 50000, false),  
(2, 3, 2025, 62000, true);   


INSERT INTO employee_salary_earning_deduction (salary_id, employee_earning_deduction_id, amount)
VALUES 
(1, 1, 40000.00),
(1, 2, 10000.00),
(1, 3, 5000.00),
(1, 4, 3000.00),
(1, 5, 1000.00);

SELECT id FROM employee_salary WHERE id IN (1, 2);
SELECT id FROM employee_earnings_deductions WHERE id IN (1, 2, 3, 4, 5);

SELECT constraint_name, constraint_type
FROM information_schema.table_constraints
WHERE table_name = 'employee_salary_earning_deduction';



INSERT INTO leaves (employee_id, start_date, end_date, status)
VALUES 
(1, '2025-03-10', '2025-03-12', 'Approved'), 
(2, '2025-03-05', '2025-03-08', 'Rejected'); 


delete from leaves where employee_id=2;



DROP TABLE IF EXISTS employee_salary_earning_deduction;

INSERT INTO leaves (employee_id, start_date, end_date) values
(3, '2025-03-15', '2025-03-18'); 

ALTER Table users drop COLUMN token;

select * from employees;
select * from users;

select * from earning_deduction_master;
select * from employee_earnings_deductions;

select * from employee_salary;

select * from employee_salary_earning_deduction;

select * from leaves;

SELECT ed.* FROM employee_salary es,employee_salary_earning_deduction ed where es.id = ed.salary_id and  es.employee_id =1 and es.month = 3 and es.year=2025;

UPDATE employees
SET name = 'Krishna', DOB = '2004-02-14'
WHERE name = 'Yash Chary';

UPDATE employees
SET name = 'Bhanu', DOB = '2003-12-25'
WHERE name = 'Anu Verma';

UPDATE employees
SET name = 'Vikranth', DOB = '2003-07-16'
WHERE name = 'Priya Gupta';

UPDATE employees
SET name = 'Pruthvi', DOB = '2004-02-11'
WHERE name = 'Neha Singh';

UPDATE employees
SET name = 'Akshith', DOB = '2003-07-10'
WHERE name = 'Rajesh Kumar';



UPDATE users
SET email = 'krishna@gmail.com', password = md5('abcd@1234')
WHERE email = 'yash.chary@gmail.com';

UPDATE users
SET email = 'bhanu@gmail.com', password = md5('abcd@1234')
WHERE email = 'anu.verma@gmail.com';

UPDATE users
SET email = 'vikranth@gmail.com', password = md5('abcd@1234')
WHERE email = 'priya.gupta@gmail.com';

UPDATE users
SET email = 'pruthvi@gmail.com', password = md5('abcd@1234')
WHERE email = 'neha.singh@gmail.com';

UPDATE users
SET email = 'akshith@gmail.com', password = md5('abcd@1234')
WHERE email = 'rajesh.kumar@gmail.com';