<?php
require_once("../../vendor/autoload.php");
require_once("../../src/Database.php");
require_once("../../src/Response.php");
require_once("../../src/Auth.php");

header("Content-Type: application/json");

try {
    $headers = getallheaders();
    $authHeader = $headers["Authorization"] ?? $headers["authorization"] ?? null;

    if (!$authHeader || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        Response::error("Unauthorized Access - No token provided", 401);
    }

    $token = $matches[1];
    $authenticatedUser = JwtManager::decodeToken($token);

    if (!$authenticatedUser) {
        Response::error("Invalid or expired token.", 401);
    }

    $userId = $authenticatedUser["id"];
    $role = $authenticatedUser["role"];

    if (!isset($role) || ($role !== "user" && $role !== "admin")) {
        Response::error("Access Denied. Only users can access this resource.", 403);
    }

    $employeeQuery = "SELECT e.* FROM employees e JOIN users u ON e.id = u.employee_id WHERE u.id = :userId";
    $employeeStmt = $pdo->prepare($employeeQuery);
    $employeeStmt->bindParam(":userId", $userId, PDO::PARAM_INT);
    $employeeStmt->execute();
    $employee = $employeeStmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        Response::error("Employee not found.", 404);
    }

    $employeeId = $employee['id'];

    $requestType = $_GET['type'] ?? 'list';

    if ($requestType === 'list') {
        $salaryQuery = "SELECT id, month, year, net_salary, created_at 
                        FROM employee_salary 
                        WHERE employee_id = :employeeId AND salary_paid = true
                        ORDER BY year DESC, month DESC";

        $salaryStmt = $pdo->prepare($salaryQuery);
        $salaryStmt->bindParam(":employeeId", $employeeId, PDO::PARAM_INT);
        $salaryStmt->execute();
        $salaries = $salaryStmt->fetchAll(PDO::FETCH_ASSOC);

        Response::success("Salary history fetched successfully.", $salaries);
    } elseif ($requestType === 'details' && isset($_GET['salary_id'])) {
        $salaryId = $_GET['salary_id'];

        $verifyQuery = "SELECT id, month, year, net_salary 
                        FROM employee_salary 
                        WHERE id = :salaryId AND employee_id = :employeeId";
        $verifyStmt = $pdo->prepare($verifyQuery);
        $verifyStmt->bindParam(":salaryId", $salaryId, PDO::PARAM_INT);
        $verifyStmt->bindParam(":employeeId", $employeeId, PDO::PARAM_INT);
        $verifyStmt->execute();
        $salaryInfo = $verifyStmt->fetch(PDO::FETCH_ASSOC);

        if (!$salaryInfo) {
            Response::error("Salary record not found or access denied.", 404);
        }

        $componentsQuery = "SELECT 
                                edm.description, 
                                edm.type,
                                esed.amount
                            FROM employee_salary_earning_deduction esed
                            JOIN employee_earnings_deductions eed ON esed.employee_earning_deduction_id = eed.id
                            JOIN earning_deduction_master edm ON eed.earning_deduction_id = edm.id
                            WHERE esed.salary_id = :salaryId AND esed.status = true
                            ORDER BY edm.type, edm.description";

        // Try to get data from employee_salary_earning_deduction first
        try {
            $componentsStmt = $pdo->prepare($componentsQuery);
            $componentsStmt->bindParam(":salaryId", $salaryId, PDO::PARAM_INT);
            $componentsStmt->execute();
            $components = $componentsStmt->fetchAll(PDO::FETCH_ASSOC);

            // If no components found, try the fallback
            if (empty($components)) {
                error_log("No components found in employee_salary_earning_deduction for salary_id: $salaryId");
                throw new Exception("No components found");
            }
        } catch (Exception $componentError) {
            // Fallback: Get data directly from employee_earnings_deductions
            error_log("Falling back to employee_earnings_deductions table for employee_id: $employeeId");

            $directQuery = "SELECT 
                                edm.description, 
                                edm.type,
                                eed.amount
                            FROM employee_earnings_deductions eed
                            JOIN earning_deduction_master edm ON eed.earning_deduction_id = edm.id
                            WHERE eed.employee_id = :employeeId
                            ORDER BY edm.type, edm.description";

            $directStmt = $pdo->prepare($directQuery);
            $directStmt->bindParam(":employeeId", $employeeId, PDO::PARAM_INT);
            $directStmt->execute();
            $components = $directStmt->fetchAll(PDO::FETCH_ASSOC);
        }

        // Process components to separate earnings and deductions
        $earnings = [];
        $deductions = [];

        // Check if we have any components
        if (empty($components)) {
            // Log the issue for debugging
            error_log("No salary components found for salary_id: $salaryId, employee_id: $employeeId");

            // Try to get at least the basic structure from earning_deduction_master
            $masterQuery = "SELECT description, type FROM earning_deduction_master ORDER BY type, description";
            $masterStmt = $pdo->prepare($masterQuery);
            $masterStmt->execute();
            $masterComponents = $masterStmt->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($masterComponents)) {
                foreach ($masterComponents as $component) {
                    if ($component['type'] == 0) { // Earnings
                        $earnings[] = [
                            'description' => $component['description'],
                            'amount' => 0
                        ];
                    } else { // Deductions
                        $deductions[] = [
                            'description' => $component['description'],
                            'amount' => 0
                        ];
                    }
                }
            } else {
                // If even master data is not available, add placeholders
                $earnings[] = [
                    'description' => 'No earnings data available',
                    'amount' => 0
                ];

                $deductions[] = [
                    'description' => 'No deductions data available',
                    'amount' => 0
                ];
            }
        } else {
            foreach ($components as $component) {
                if ($component['type'] == 0) { // Earnings
                    $earnings[] = [
                        'description' => $component['description'],
                        'amount' => $component['amount']
                    ];
                } else { // Deductions
                    $deductions[] = [
                        'description' => $component['description'],
                        'amount' => $component['amount']
                    ];
                }
            }
        }

        $leavesQuery = "SELECT 
                            start_date, end_date, total_leaves, status
                        FROM leaves
                        WHERE employee_id = :employeeId
                        AND (
                            (EXTRACT(MONTH FROM start_date) = :month AND EXTRACT(YEAR FROM start_date) = :year)
                            OR 
                            (EXTRACT(MONTH FROM end_date) = :month AND EXTRACT(YEAR FROM end_date) = :year)
                        )
                        AND status = 'Approved'";

        $leavesStmt = $pdo->prepare($leavesQuery);
        $leavesStmt->bindParam(":employeeId", $employeeId, PDO::PARAM_INT);
        $leavesStmt->bindParam(":month", $salaryInfo['month'], PDO::PARAM_INT);
        $leavesStmt->bindParam(":year", $salaryInfo['year'], PDO::PARAM_INT);
        $leavesStmt->execute();
        $leaves = $leavesStmt->fetchAll(PDO::FETCH_ASSOC);

        // Log leave data for debugging
        error_log("Leave data for employee $employeeId, month {$salaryInfo['month']}, year {$salaryInfo['year']}: " . json_encode($leaves));

        // Calculate total earnings and deductions
        $totalEarnings = array_sum(array_column($earnings, 'amount'));
        $totalDeductions = array_sum(array_column($deductions, 'amount'));

        // Add debug information
        $dataSource = 'employee_salary_earning_deduction';
        if (isset($componentError)) {
            $dataSource = 'employee_earnings_deductions (fallback)';
        }
        if (empty($components) && isset($masterComponents)) {
            $dataSource = 'earning_deduction_master (empty data fallback)';
        }

        $debug = [
            'salary_id' => $salaryId,
            'employee_id' => $employeeId,
            'components_count' => count($components),
            'earnings_count' => count($earnings),
            'deductions_count' => count($deductions),
            'data_source' => $dataSource
        ];

        // Format leave data to ensure it's properly structured
        $formattedLeaves = [];
        foreach ($leaves as $leave) {
            $formattedLeaves[] = [
                'start_date' => $leave['start_date'],
                'end_date' => $leave['end_date'],
                'total_leaves' => $leave['total_leaves'],
                'status' => $leave['status']
            ];
        }

        Response::success("Salary details fetched successfully.", [
            'employee' => $employee,
            'salary_info' => $salaryInfo,
            'earnings' => $earnings,
            'deductions' => $deductions,
            'total_earnings' => $totalEarnings,
            'total_deductions' => $totalDeductions,
            'leaves' => $formattedLeaves
        ]);
    } else {
        Response::error("Invalid request type.", 400);
    }
} catch (Exception $e) {
    Response::error("Server error: " . $e->getMessage(), 500);
}
